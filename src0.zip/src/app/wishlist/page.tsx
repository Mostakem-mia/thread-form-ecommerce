"use client";

import { useWishlist } from "@/context/wishlist-context";
import Link from "next/link";
import ProductCard from "@/components/product-card";

export default function WishlistPage() {
    const { wishlist } = useWishlist();

    if (wishlist.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
                <h2 className="text-2xl font-bold text-gray-800">Your Wishlist is Empty</h2>
                <p className="text-gray-500 mt-2">Explore our collection and add your favorite items!</p>
                <Link
                    href="/shop"
                    className="mt-6 rounded-md bg-black px-6 py-2.5 text-white hover:bg-gray-800 transition"
                >
                    Explore Shop
                </Link>
            </div>
        );
    }

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <h1 className="text-3xl font-bold text-gray-900 mb-8">My Wishlist ({wishlist.length})</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {wishlist.map((product) => (
                    <ProductCard key={product.id} product={product} />
                ))}
            </div>
        </div>
    );
}